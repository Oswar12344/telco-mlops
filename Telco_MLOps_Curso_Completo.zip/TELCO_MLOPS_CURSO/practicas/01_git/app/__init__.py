"""Aplicación FastAPI."""
